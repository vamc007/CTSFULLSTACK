package com.cts.scheduletraining.bo;

public interface TrainingScheduleBO {

	public Long generateId();
}
