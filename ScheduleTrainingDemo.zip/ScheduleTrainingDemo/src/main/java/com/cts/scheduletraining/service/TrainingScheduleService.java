package com.cts.scheduletraining.service;

import com.cts.scheduletraining.vo.TrainingScheduleVO;

public interface TrainingScheduleService {

	public Boolean addSchedule(TrainingScheduleVO trainingScheduleVO);
}
