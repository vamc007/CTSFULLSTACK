package com.cts.scheduletraining.dao;

import com.cts.scheduletraining.vo.TrainingScheduleVO;

public interface TrainingScheduleDAO {

	
	public Boolean saveScheduleDetail(TrainingScheduleVO trainingScheduleVO);
}
