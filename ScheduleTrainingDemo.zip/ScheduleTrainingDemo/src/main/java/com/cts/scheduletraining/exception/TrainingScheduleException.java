package com.cts.scheduletraining.exception;

public class TrainingScheduleException extends Exception {

	public TrainingScheduleException(String message)
	{
		super(message);
	}
}
